typedef struct Point Point;
void main();