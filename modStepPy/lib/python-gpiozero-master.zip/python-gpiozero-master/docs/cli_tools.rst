==================
Command-line Tools
==================

The gpiozero package contains a database of information about the various
revisions of Raspberry Pi. This is queried by the :program:`pinout`
command-line tool to output details of the GPIO pins available.

.. include:: cli_pinout.rst
